<?php
    session_start();
    include "../conecta/conecta.php";
    $cpf = $_POST['cpf'];
    $senha = $_POST['senha'];
    $logar = mysqli_query($con, "SELECT * FROM usuario WHERE cpf='$cpf' AND senha='$senha'");
    if(mysqli_num_rows($logar)>0)
    {
        $_SESSION["user"] = $_POST['cpf'];
        header('location:../menu/menu.php');
    }
    else 
    {
        echo ("<script>alert('Login ou senha incorretos! Tente novamente.');window.location.href='../login/index.html';</script>");
    }
?>