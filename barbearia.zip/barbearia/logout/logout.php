<?php
require_once("../conecta/conecta.php"); // Inicia a sessão

if (isset($_POST["Sair"])) 
    $_SESSION = array(); // Limpa todas as variáveis de sessão

    session_destroy(); // Destrói a sessão

    ?>
    <script>
        window.location.href = "../login/login.php";
        alert("Sessão deletada");
    </script>


