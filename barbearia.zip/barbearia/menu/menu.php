<?php
include "../conecta/conecta.php";

 if (!isset($_SESSION)) session_start(); //se a sessão n for iniciado
 if (!isset($_SESSION["user"])) //se a sessão "user" n for iniciado 
 {
     session_destroy(); //destroi a sessão
     header("Location: ../login/login.php"); //manda o user pro index
     exit;
 }
 
    $usuario = $_SESSION["user"];
    $pesquisa = mysqli_query($con, "SELECT cpf,tipo FROM usuario WHERE cpf=$usuario");
    $row = mysqli_num_rows($pesquisa);
    if($row > 0){
        while($registro = $pesquisa-> fetch_array()){
            $tipo = $registro['tipo'];
        }
    }
    if ($tipo == "admin") {
        header('Location: ../home_admin/admin.php');
    }
    else if ($tipo == "funcionario") {
        header('Location: ../home_funcionario/funcionario.php');
    }
    else if ($tipo == "cliente") {
        header('Location: ../home_cliente/index.html');
    }
    else {
        header('Location: ../home_visitante/index.html');
    }
