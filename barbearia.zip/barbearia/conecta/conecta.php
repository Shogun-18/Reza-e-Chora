<?php
    $con = mysqli_connect("localhost","root","","barbearia");
    if(!$con)
    {
       echo "erro";
    }
?>