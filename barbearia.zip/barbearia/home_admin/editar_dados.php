<?php
include ("conecta.php");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Admin</title>
    <link rel="stylesheet" type="text/css" href="admin.css" media="screen"/>
</head>
<body>
    <div class="navbar">
        <a href="cadastro.php">Cadastro Funcionário</a>
        <a href="dados_funcionario.php">Dados dos Funcionários</a>
        <a href="historico.php">Histórico de Pagamentos</a>
        <a href="meusdados.php">Meus Dados</a>
        <a href="../logout/logout.php">Sair</a>
    </div>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <title>Página Admin - Editar Dados</title>
</head>
<body>
    <?php
    // Verifica se o formulário foi enviado
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Recupera os dados do formulário
        $nome = $_POST["nome"];
        $email = $_POST["email"];
        $senha = $_POST["senha"];

        // Atualiza os dados do admin no banco de dados
        $sql = "UPDATE admin SET nome='$nome', email='$email', senha='$senha' WHERE id = 1"; // Substitua "1" pelo ID correto do admin
        if ($conn->query($sql) === true) {
            echo "Dados atualizados com sucesso!";
        } else {
            echo "Erro ao atualizar os dados: " . $conn->error;
        }
    }

    // Recupera os dados do admin do banco de dados
    $sql = "SELECT * FROM admin WHERE id = 1"; // Substitua "1" pelo ID correto do admin
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nome = $row["nome"];
        $email = $row["email"];
        $senha = $row["senha"];

        // Exibe o formulário para editar os dados
        echo "<h1>Editar Meus Dados</h1>";
        echo "<form method='POST' action='" . $_SERVER["PHP_SELF"] . "'>";
        echo "<label>Nome:</label>";
        echo "<input type='text' name='nome' value='$nome' required><br>";
        echo "<label>Email:</label>";
        echo "<input type='email' name='email' value='$email' required><br>";
        echo "<label>Senha:</label>";
        echo "<input type='password' name='senha' value='$senha' required><br>";
        echo "<input type='submit' value='Salvar'>";
        echo "</form>";
    } else {
        echo "Nenhum dado encontrado.";
    }
    ?>
</body>
</html>
