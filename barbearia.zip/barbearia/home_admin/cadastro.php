<?php
include ("conecta.php");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Admin</title>
    <link rel="stylesheet" type="text/css" href="admin.css" media="screen"/>
</head>
<body>
    <div class="navbar">
        <a href="cadastro.php">Cadastro Funcionário</a>
        <a href="dados_funcionario.php">Dados dos Funcionários</a>
        <a href="historico.php">Histórico de Pagamentos</a>
        <a href="meusdados.php">Meus Dados</a>
        <a href="../logout/logout.php">Sair</a>
    </div>
</body>
</html>

<?php
// Cadastro de Funcionário
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["cadastrar_funcionario"])) {
    $nome = $_POST["nome"];
    $sobrenome = $_POST["sobrenome"];
    $cargo = $_POST["cargo"];
    $data_admissao = $_POST["data_admissao"];
    $salario = $_POST["salario"];

    // Validação dos dados (adapte às suas necessidades)

    // Inserção dos dados no banco de dados
    $sql = "INSERT INTO funcionarios (nome, sobrenome, cargo, data_admissao, salario)
            VALUES ('$nome', '$sobrenome', '$cargo', '$data_admissao', '$salario')";

    if ($conn->query($sql) === true) {
        echo "Funcionário cadastrado com sucesso!";
    } else {
        echo "Erro ao cadastrar o funcionário: " . $conn->error;
    }
}

// Listagem de Funcionários
$sql = "SELECT * FROM funcionarios";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Página Admin</title>
</head>
<body>
    <h1>Cadastro de Funcionário</h1>
    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <label>Nome:</label>
        <input type="text" name="nome" required><br>

        <label>Sobrenome:</label>
        <input type="text" name="sobrenome" required><br>

        <label>Cargo:</label>
        <input type="text" name="cargo" required><br>

        <label>Data de Admissão:</label>
        <input type="date" name="data_admissao" required><br>

        <label>Salário:</label>
        <input type="number" name="salario" required><br>

        <input type="submit" name="cadastrar_funcionario" value="Cadastrar">
    </form>

    
</body>
</html>

<?php
// Fechamento da conexão com o banco de dados
$conn->close();
?>
