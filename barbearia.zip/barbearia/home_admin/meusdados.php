<?php
include ("conecta.php");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Admin</title>
    <link rel="stylesheet" type="text/css" href="admin.css" media="screen"/>
</head>
<body>
    <div class="navbar">
        <a href="cadastro.php">Cadastro Funcionário</a>
        <a href="dados_funcionario.php">Dados dos Funcionários</a>
        <a href="historico.php">Histórico de Pagamentos</a>
        <a href="meusdados.php">Meus Dados</a>
        <a href="../logout/logout.php">Sair</a>
    </div>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <title>Página Admin - Meus Dados</title>
</head>
<body>
    <?php
    // Recupera os dados do admin do banco de dados
    $sql = "SELECT * FROM admin WHERE id = 1"; // Substitua "1" pelo ID correto do admin
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nome = $row["nome"];
        $email = $row["email"];
        $senha = $row["senha"];

        // Exibe os dados do admin
        echo "<h1>Meus Dados</h1>";
        echo "<p><strong>Nome:</strong> $nome</p>";
        echo "<p><strong>Email:</strong> $email</p>";
        echo "<p><strong>Senha:</strong> $senha</p>";
    } else {
        echo "Nenhum dado encontrado.";
    }
    ?>

    <!-- Link para editar os dados -->
    <a href="editar_dados.php">Editar Meus Dados</a>
</body>
</html>
