<?php
include ("conecta.php");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Admin</title>
    <link rel="stylesheet" type="text/css" href="admin.css" media="screen"/>
</head>
<body>
    <div class="navbar">
        <a href="cadastro.php">Cadastro Funcionário</a>
        <a href="dados_funcionario.php">Dados dos Funcionários</a>
        <a href="historico.php">Histórico de Pagamentos</a>
        <a href="meusdados.php">Meus Dados</a>
        <a href="../logout/logout.php">Sair</a>
    </div>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <title>Página Admin</title>
</head>
<body>
    <h1>Histórico de Pagamentos</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Funcionário</th>
            <th>Data</th>
            <th>Valor</th>
        </tr>
        <?php
        $sql = "SELECT hp.id, CONCAT(f.nome, ' ', f.sobrenome) as nome_funcionario, hp.data, hp.valor
                FROM historico_pagamentos hp
                INNER JOIN funcionarios f ON hp.funcionario_id = f.id";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["nome_funcionario"] . "</td>";
                echo "<td>" . $row["data"] . "</td>";
                echo "<td>" . $row["valor"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Nenhum pagamento registrado.</td></tr>";
        }
        ?>
    </table>
</body>
</html>

<?php
// Fechamento da conexão com o banco de dados
$conn->close();
?>

