<?php
include ("conecta.php");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Página Admin</title>
    <link rel="stylesheet" type="text/css" href="admin.css" media="screen"/>
</head>
<body>
    <div class="navbar">
        <a href="cadastro.php">Cadastro Funcionário</a>
        <a href="dados_funcionario.php">Dados dos Funcionários</a>
        <a href="historico.php">Histórico de Pagamentos</a>
        <a href="meusdados.php">Meus Dados</a>
        <a href="../logout/logout.php">Sair</a>
    </div>
</body>
</html>

<h1>Dados dos Funcionários</h1>
    <table>
        <tr>
            <th>Nome</th>
            <th>Sobrenome</th>
            <th>Cargo</th>
            <th>Data de Admissão</th>
            <th>Salário</th>
        </tr>
        <?php
        // Listagem de Funcionários
        $sql = "SELECT * FROM funcionarios";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["nome"] . "</td>";
                echo "<td>" . $row["sobrenome"] . "</td>";
                echo "<td>" . $row["cargo"] . "</td>";
                echo "<td>" . $row["data_admissao"] . "</td>";
                echo "<td>" . $row["salario"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Nenhum funcionário cadastrado.</td></tr>";
        }
        // Fechamento da conexão com o banco de dados
        $conn->close();
        ?>
    </table>
