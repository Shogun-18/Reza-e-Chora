<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-light navbar-light fixed-top">
  <div class="container">
      <a class="navbar-brand" href="../menu/menu.php">MODERNA</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
          aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="../menu/menu.php">Home</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../produtos/produtos.html">Serviços</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../agendamento/agendamento.php">Agendamento</a>
              </li>
              <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                      aria-expanded="false">
                      Usuário
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end ">
                      <li><a class="dropdown-item" href="../home_cliente\meus_dados_cliente.php">Meus Dados</a></li>
                      <li><a class="dropdown-item" href="../agendamento/meus_agendamentos.php">Agendamentos</a>
                      </li>
                      <li><a class="dropdown-item" href="../logout/logout.php">Sair</a></li>
                  </ul>
              </li>
          </ul>
      </div>
  </div>
</nav>

<br/>

    <center><h3>Carrinho</h3></center>
    <br/>
    <table class="table border border-black">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Id do usuário</th>
      <th scope="col">Servico</th>
      <th scope="col">Barbeiro</th>
      <th scope="col">Total</th>
      <th scope="col">Data</th>
      <th scope="col">Hora</th>
    </tr>
  </thead>
    <?php

    include '../conecta/conecta.php';
    $query = mysqli_query($con, "SELECT * FROM agendamento");
    if ($query->num_rows > 0) {
        while ($agendamento = $query->fetch_array()) {
            $id = $agendamento['id'];
            echo '<tr>';
            echo '<th scope="row">' . $agendamento['id'] . '</th>';
            echo '<td>' . $agendamento['usuario_id'] . '</td>';
            echo '<td>' . $agendamento['servicos'] . '</td>';
            echo '<td>' . $agendamento['barbeiro'] . '</td>';
            echo '<td>' . $agendamento['total'] . '</td>';
            echo '<td>' . $agendamento['data'] . '</td>';
            echo '<td>' . $agendamento['hora'] . '</td>';
           
        }
    }

    ?>
    
</body>
</html>