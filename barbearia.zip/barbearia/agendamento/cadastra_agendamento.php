<?php

include "../conecta/conecta.php";


$data = $_POST["data"];
$hora = $_POST["hora"];

//receber id do cliente
$query = mysqli_query($con, "SELECT * FROM usuario");
if ($query->num_rows > 0) {
    while ($usuario = $query->fetch_array()) {
        $usuario_id = $usuario['id'];
    }
}


if (isset($_POST['servicos'])) {
    $soma_servicos = 0;
    foreach ($_POST['servicos'] as $valor_servicos) {
        $soma_servicos += $valor_servicos;
    }
}

if (isset($_POST['barbeiro'])) {
    $soma_barbeiros = 0;
    foreach ($_POST['barbeiro'] as $valor_barbeiros) {
        $soma_barbeiros += $valor_barbeiros;
    }
}

if($soma_servicos == 30 && $soma_barbeiros == 1){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Cabelo','Douglas','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}
if($soma_servicos == 30 && $soma_barbeiros == 2){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Cabelo','Fernando','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}

if($soma_servicos == 30 && $soma_barbeiros == 3){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Cabelo','Kauã','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}

if($soma_servicos == 30 && $soma_barbeiros == 4){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Cabelo','Maria','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}
if($soma_servicos == 30 && $soma_barbeiros == 5){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Cabelo','Shogun','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}

//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if($soma_servicos == 25 && $soma_barbeiros == 1){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Barba','Douglas','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}

if($soma_servicos == 25 && $soma_barbeiros == 2){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Barba','Fernando','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}

if($soma_servicos == 25 && $soma_barbeiros == 3){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Barba','Kauã','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}

if($soma_servicos == 25 && $soma_barbeiros == 4){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Barba','Maria','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}

if($soma_servicos == 25 && $soma_barbeiros == 5){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Barba','Shogun','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}



//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if($soma_servicos == 50 && $soma_barbeiros == 1){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Cabelo e barba','Douglas','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}

if($soma_servicos == 50 && $soma_barbeiros == 2){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Cabelo e Barba','Fernando','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}

if($soma_servicos == 50 && $soma_barbeiros == 3){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Cabelo e Barba','Kauã','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}

if($soma_servicos == 50 && $soma_barbeiros == 4){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Cabelo e Barba','Maria','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}

if($soma_servicos == 50 && $soma_barbeiros == 5){
    $sql = "INSERT INTO agendamento(usuario_id,servicos,barbeiro,total,data,hora) VALUES ('{$usuario_id}','Cabelo e Barba','Shogun','{$soma_servicos}','{$data}','{$hora}')";
        if (mysqli_query($con, $sql)) {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        } else {
            echo "<script language='javascript' type/javascript'>
            alert('Agendamento não cadastrado!');
            window.location.href='agendamento.php';
            </script>";
        }
}

    else{
        echo "<script language='javascript' type/javascript'>
        alert('Selecione ao menos uma opção!');
        window.location.href='agendamento.php';
        </script>";
    }
   
?>


