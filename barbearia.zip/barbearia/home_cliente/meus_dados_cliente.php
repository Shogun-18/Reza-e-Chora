<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/style1.css">

<body>
<nav class="navbar navbar-expand-lg bg-light navbar-light fixed-top">
  <div class="container">
      <a class="navbar-brand" href="../menu/menu.php">MODERNA</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
          aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="../menu/menu.php">Home</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../produtos/produtos.html">Serviços</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../agendamento/agendamento.php">Agendamento</a>
              </li>
              <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                      aria-expanded="false">
                      Usuário
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end ">
                      <li><a class="dropdown-item" href="../home_cliente\meus_dados_cliente.php">Meus Dados</a></li>
                      <li><a class="dropdown-item" href="../agendamento/meus_agendamentos.php">Agendamentos</a>
                      </li>
                      <li><a class="dropdown-item" href="../logout/logout.php">Sair</a></li>
                  </ul>
              </li>
          </ul>
      </div>
  </div>
</nav>
  
  <title>Dados do Cliente</title>
</head>
<body>
  <h1>Dados do Cliente</h1>

  <h2>Informacoes do Cliente</h2>
  <p>Nome: <span id="nome"></span></p>
  <p>Email: <span id="email"></span></p>

  <h2>Compras</h2>
  <table>
    <thead>
      <tr>
        <th>Produto</th>
        <th>Quantidade</th>
        <th>Data</th>
        <th>Preco</th>
      </tr>
    </thead>
    <tbody id="compras">
      <!-- Os dados das compras serão adicionados aqui -->
    </tbody>
  </table>

  <script>
    // Dados do cliente
    var cliente = {
      nome: "Joao da Silva",
      email: "joao@example.com",
    };

    // Dados das compras
    var compras = [
      {
        produto: "corte",
        quantidade: 2,
        preco: 29.99
      },
      {
        produto: "Barba",
        quantidade: 1,
        preco: 59.99
      }
    ];

    // Preenche os dados do cliente
    document.getElementById("nome").textContent = cliente.nome;
    document.getElementById("email").textContent = cliente.email;

    // Preenche os dados das compras
    var tabelaCompras = document.getElementById("compras");
    for (var i = 0; i < compras.length; i++) {
      var compra = compras[i];
      var linha = document.createElement("tr");

      var colunaProduto = document.createElement("td");
      colunaProduto.textContent = compra.produto;
      linha.appendChild(colunaProduto);

      var colunaQuantidade = document.createElement("td");
      colunaQuantidade.textContent = compra.quantidade;
      linha.appendChild(colunaQuantidade);

      var colunaPreco = document.createElement("td");
      colunaPreco.textContent = compra.preco;
      linha.appendChild(colunaPreco);

      tabelaCompras.appendChild(linha);
    }
  </script>
</body>
</html>