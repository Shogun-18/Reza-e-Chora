<!DOCTYPE html>
<html>
<head>
    <title>Página Funcionário</title>
    <link rel="stylesheet" type="text/css" href="funcionario.css" media="screen"/>
</head>
<body>
    <div class="navbar">
        <a href="agenda_servico.php">Agenda de Serviços</a>
        <a href="meus_dados.php">Meus Dados</a>
        <a href="../logout/logout.php">Sair</a>
    </div>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <title>Agenda de Serviços</title>
  <style>
    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
  <h1>Agenda de Serviços</h1>

  <table>
    <thead>
      <tr>
        <th>Nome do Cliente</th>
        <th>Data do Pedido</th>
        <th>Hora Agendada</th>
        <th>Valor do Serviço</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Cliente 1</td>
        <td>01/07/2023</td>
        <td>10:00</td>
        <td>R$ 50,00</td>
      </tr>
      <tr>
        <td>Cliente 2</td>
        <td>02/07/2023</td>
        <td>14:30</td>
        <td>R$ 80,00</td>
      </tr>
      <tr>
        <td>Cliente 3</td>
        <td>03/07/2023</td>
        <td>16:00</td>
        <td>R$ 100,00</td>
      </tr>
    </tbody>
  </table>

</body>
</html>
