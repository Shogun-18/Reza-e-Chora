<?php
if (!isset($_SESSION)) session_start(); //se a sessão n for iniciado
if (!isset($_SESSION["user"])) //se a sessão "user" n for iniciado 
{
    session_destroy(); //destroi a sessão
    header("Location: index.php"); //manda o user pro index
    // exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Página Funcionário</title>
    <link rel="stylesheet" type="text/css" href="funcionario.css" media="screen"/>
</head>
<body>
    <div class="navbar">
        <a href="agenda_servico.php">Agenda de Serviços</a>
        <a href="meus_dados.php">Meus Dados</a>
        <a href="../logout/logout.php">Sair</a>
    </div>
</body>
</html>

<?php

    include("../conecta/conecta.php");

    // Verifica se foi passado o ID do funcionário na URL
    if (isset($_GET['id']) && !empty($_GET['id'])) {
        // Obtém o ID do funcionário da URL
        $funcionarioId = $_GET['id'];

        // Consulta o registro do funcionário atual
        $sql = "SELECT id, nome, sobrenome, email, cpf FROM usuario WHERE id = $funcionarioId";
        $result = $conn->query($sql);

        // Verifica se o funcionário foi encontrado
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Meus Dados</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <h2>Meus Dados</h2>
    
    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Sobrenome</th>
            <th>Email</th>
            <th>CPF</th>
        </tr>
        
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['nome']; ?></td>
            <td><?php echo $row['sobrenome']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['cpf']; ?></td>
        </tr>
    </table>
</body>
</html>
<?php
        } else {
            echo "Funcionário não encontrado.";
        }

        // Fecha a conexão com o banco de dados
        $conn->close();
    } 
?>
