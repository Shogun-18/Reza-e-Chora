<!DOCTYPE html>
<html>
<head>
    <title>Página Funcionário</title>
    <link rel="stylesheet" type="text/css" href="funcionario.css" media="screen"/>
</head>
<body>
    <div class="navbar">
        <a href="agenda_servico.php">Agenda de Serviços</a>
        <a href="meus_dados.php">Meus Dados</a>
        <a href="../logout/logout.php">Sair</a>
    </div>
</body>
</html>